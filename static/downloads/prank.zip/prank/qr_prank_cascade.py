# qr_prank_cascade.py
# Prank popup script with QR + sound + random jitter
#
# Config:
#   COPIES = 50
#   SPAWN_DELAY_MS = 60
#   AUTO_CLOSE_MINUTES = 1
#   PLAY_EVERY_NTH = 3
#   Volume = 15% (macOS afplay)
#
# Requires: pillow
# Run: python3 qr_prank_cascade.py

import tkinter as tk
from PIL import Image, ImageTk
import os
import threading
import subprocess
import sys
import random

# ---------------- CONFIG ----------------
QR_FILENAME = "47237.jpg"        # QR image (same folder)
SOUND_FILENAME = "error.mp3"     # sound file (same folder)
COPIES = 30
WINDOW_W, WINDOW_H = 320, 360
START_X, START_Y = 200, 200
DX, DY = 25, 18
SPAWN_DELAY_MS = 60              # milliseconds between spawning
AUTO_CLOSE_MINUTES = 1           # auto-close after 1 minute
PLAY_EVERY_NTH = 5               # play sound every 3rd popup
JITTER = 15                      # random jitter in pixels
# ----------------------------------------

PRANK_TEXT = (
    "Your computer is infected!\n\n"
    "JUST A PRANK!!! DO NOT SEND MONEY!!!\n\n"
    "Scan the QR for a surprise."
)

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
qr_path = os.path.join(BASE_DIR, QR_FILENAME)
sound_path = os.path.join(BASE_DIR, SOUND_FILENAME)

if not os.path.exists(qr_path):
    print(f"Error: QR image not found: {qr_path}")
    raise SystemExit
if not os.path.exists(sound_path):
    print(f"Warning: Sound file not found: {sound_path}")
    sound_path = None

# Load QR image
img = Image.open(qr_path)
max_qr = 200
w, h = img.size
scale = min(max_qr / w, max_qr / h, 1.0)
try:
    resample_filter = Image.Resampling.LANCZOS
except AttributeError:
    resample_filter = Image.LANCZOS
img = img.resize((int(w * scale), int(h * scale)), resample_filter)

# Play sound helper
def _play_with_subprocess(path):
    if sys.platform == "darwin":  # macOS with volume control
        try:
            subprocess.Popen(["afplay", "-v", "0.15", path])  # 15% volume
            return True
        except Exception:
            return False
    elif sys.platform.startswith("win"):  # Windows fallback
        try:
            os.startfile(path)
            return True
        except Exception:
            return False
    else:  # Linux fallback
        for cmd in (["mpg123", path], ["ffplay", "-nodisp", "-autoexit", path]):
            try:
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return True
            except Exception:
                continue
    return False

def play_sound_async(path):
    if not path:
        return
    def _worker():
        _play_with_subprocess(path)
    threading.Thread(target=_worker, daemon=True).start()

# Main root (hidden)
root = tk.Tk()
root.withdraw()

windows = []
photo_images = []

# Control window
ctrl = tk.Toplevel()
ctrl.title("Prank control")
ctrl.geometry("260x100+50+50")
ctrl.attributes("-topmost", True)

def stop_all():
    for w in list(windows):
        try: w.destroy()
        except: pass
    windows.clear()
    photo_images.clear()
    try: ctrl.destroy()
    except: pass
    try: root.destroy()
    except: pass

stop_btn = tk.Button(ctrl, text="STOP PRANK", fg="white", bg="red",
                     command=stop_all, font=("Helvetica", 11, "bold"))
stop_btn.pack(expand=True, fill="both", padx=10, pady=12)

# Create popup
def make_popup(index):
    if sound_path and (index % PLAY_EVERY_NTH == 0):
        play_sound_async(sound_path)

    # Base cascade position
    x = START_X + index * DX
    y = START_Y + index * DY

    # Add random jitter
    x += random.randint(-JITTER, JITTER)
    y += random.randint(-JITTER, JITTER)

    t = tk.Toplevel()
    t.title("Error")
    t.geometry(f"{WINDOW_W}x{WINDOW_H}+{x}+{y}")
    t.attributes("-topmost", True)

    frame = tk.Frame(t, bg="#dcdcdc")
    frame.pack(expand=True, fill="both")

    title_bar = tk.Frame(frame, bg="#00008b", height=28)
    title_bar.pack(fill="x")
    title_lbl = tk.Label(title_bar, text="Error", fg="white", bg="#00008b",
                         font=("Helvetica", 10, "bold"))
    title_lbl.place(x=6, y=4)

    content = tk.Frame(frame, bg="#f0f0f0")
    content.pack(expand=True, fill="both", padx=8, pady=8)

    photo = ImageTk.PhotoImage(img, master=t)
    photo_images.append(photo)
    img_label = tk.Label(content, image=photo, bg="#f0f0f0")
    img_label.pack(pady=(6, 8))

    text_lbl = tk.Label(content, text=PRANK_TEXT, bg="#f0f0f0", fg="black",
                        justify="center", wraplength=WINDOW_W-24,
                        font=("Helvetica", 9, "bold"))
    text_lbl.pack()

    btn = tk.Button(frame, text="OK", command=t.destroy)
    btn.pack(pady=8)

    windows.append(t)

# Schedule cascade
for i in range(COPIES):
    root.after(i * SPAWN_DELAY_MS, lambda idx=i: make_popup(idx))

# Auto-close
root.after(AUTO_CLOSE_MINUTES * 60 * 1000, stop_all)

# Ctrl+Q stop
def on_key(event):
    if (event.state & 0x4) and event.keysym.lower() == 'q':
        stop_all()
ctrl.bind_all('<Key>', on_key)

root.mainloop()
